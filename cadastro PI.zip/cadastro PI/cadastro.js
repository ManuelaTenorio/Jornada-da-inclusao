document.getElementById("signup-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Impede o comportamento padrão de recarregar a página
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirm-password").value;

    // Validação simples
    if (password === confirmPassword) {
        alert("Cadastro bem-sucedido!");
        // Realizar outra ação, como redirecionar ou enviar dados
    } else {
        alert("As senhas não coincidem.");
    }
});

