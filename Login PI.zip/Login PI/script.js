document.getElementById("login-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Impede o comportamento padrão de recarregar a página
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    
    // Validação simples
    if (email === "admin@example.com" && password === "admin123") {
      alert("Login bem-sucedido!");
      // Redirecionar ou realizar outra ação aqui
    } else {
      alert("E-mail ou senha inválidos.");
    }
  });
  
